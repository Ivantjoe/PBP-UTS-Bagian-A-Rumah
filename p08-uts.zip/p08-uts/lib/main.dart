import 'package:flutter/material.dart';

import 'data.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kos Sekitar Kampus',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const LayarDaftar(),
    );
  }
}

class LayarDaftar extends StatefulWidget {
  const LayarDaftar({super.key});

  @override
  State<LayarDaftar> createState() => _LayarDaftarState();
}

class _LayarDaftarState extends State<LayarDaftar> {
  Kos dipilih = daftarKos.first;

  @override
  Widget build(BuildContext context) {
    final lebar = MediaQuery.of(context).size.width;
    final layarLebar = lebar >= 700;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kos Sekitar Kampus'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),

      body: layarLebar
          ? Row(
              children: [
                SizedBox(width: lebar * 0.4, child: daftar()),

                const VerticalDivider(width: 1),

                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: DetailKos(kos: dipilih),
                  ),
                ),
              ],
            )
          : daftar(),
    );
  }

  Widget daftar() {
    return ListView.builder(
      itemCount: daftarKos.length,
      itemBuilder: (context, index) {
        final kos = daftarKos[index];

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),

          child: ListTile(
            leading: CircleAvatar(child: Text('${index + 1}')),

            title: Text(
              kos.nama,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),

            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(kos.alamat),
                Text(kos.hargaTeks),
                Text(
                  kos.penuh
                      ? 'Kamar penuh'
                      : 'Tersedia ${kos.kamarKosong} kamar',
                ),
              ],
            ),

            trailing: const Icon(Icons.arrow_forward_ios),

            onTap: () {
              setState(() {
                dipilih = kos;
              });

              if (MediaQuery.of(context).size.width < 700) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Scaffold(
                      appBar: AppBar(title: const Text('Detail Kos')),
                      body: Padding(
                        padding: const EdgeInsets.all(16),
                        child: DetailKos(kos: kos),
                      ),
                    ),
                  ),
                );
              }
            },
          ),
        );
      },
    );
  }
}

class DetailKos extends StatefulWidget {
  const DetailKos({super.key, required this.kos});

  final Kos kos;

  @override
  State<DetailKos> createState() => _DetailKosState();
}

class _DetailKosState extends State<DetailKos> {
  bool disurvei = false;

  @override
  Widget build(BuildContext context) {
    final kos = widget.kos;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Center(
            child: Icon(Icons.apartment, size: 90, color: Colors.indigo),
          ),

          const SizedBox(height: 20),

          Text(
            kos.nama,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Text('Kode Kos: ${kos.kode}'),
          const SizedBox(height: 10),
          Text('Alamat: ${kos.alamat}'),
          const SizedBox(height: 10),
          Text('Harga: ${kos.hargaTeks}'),
          const SizedBox(height: 10),
          Text('Jenis: ${kos.jenis}'),
          const SizedBox(height: 10),
          Text(kos.penuh ? 'Kamar: Penuh' : 'Kamar kosong: ${kos.kamarKosong}'),

          const SizedBox(height: 20),
          const Text(
            'Fasilitas:',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),

          const SizedBox(height: 8),
          ...kos.fasilitas.map(
            (fasilitas) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  const Icon(Icons.check_circle, color: Colors.green, size: 20),
                  const SizedBox(width: 8),
                  Text(fasilitas),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  disurvei = !disurvei;
                });
              },

              icon: Icon(disurvei ? Icons.check_circle : Icons.location_on),

              label: Text(disurvei ? 'Sudah Disurvei' : 'Tandai Sudah Survei'),
            ),
          ),
        ],
      ),
    );
  }
}
